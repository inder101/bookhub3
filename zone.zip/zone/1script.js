// Smooth scrolling to Highlights Section
document.querySelector('.scroll-prompt').addEventListener('click', function () {
    document.getElementById('highlights').scrollIntoView({ behavior: 'smooth' });
  });
  